<?php $__env->startSection('style'); ?>
    <title>YuVie-Business: Admin</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page__content">
        <div class="dashboard">
            <div class="dashboard__start"><strong>Dashboard</strong></div>
            <div class="dashboard__container">
                <div class="dashboard__section">
                    <div class="dashboard__head">
                        
                    </div>
                    <div class="dashboard__body">
                        <div class="dashboard__list">
                            <div class="card card_big">
                                <div class="card__team">
                                    <div class="card__logo"><img class="card__pic" src="<?php echo e(asset("theme/img/logo-team-1.png")); ?>"></div>
                                    <div class="card__title">Company</div>
                                </div>
                            </div>
                            <div class="card card_big">
                                <div class="card__team">
                                    <div class="card__logo"><img class="card__pic" src="<?php echo e(asset("theme/img/logo-team-1.png")); ?>"></div>
                                    <div class="card__title">Users</div>
                                </div>
                            </div>
                            <div class="card card_big">
                                <div class="card__team">
                                    <div class="card__logo"><img class="card__pic" src="<?php echo e(asset("theme/img/logo-team-1.png")); ?>"></div>
                                    <div class="card__title">Videos</div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asadmirza/Documents/laravel/yuvi/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>