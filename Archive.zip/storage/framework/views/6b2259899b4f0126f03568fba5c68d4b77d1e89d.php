<?php $__env->startSection('style'); ?>
    <title><?php echo e('YuVie-Business:'. $title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="sorting1">
        <div class="sorting1__row">
            <h1 class="sorting1__title title"><?php echo e($title); ?> List</h1>
            <div class="sorting1__variants">
                <div class="sorting1__text">Show:</div><select class="sorting1__select">
                    <option selected>All <?php echo e($title); ?></option>
                    <option>All <?php echo e($title); ?></option>
                </select>
            </div>
            <div class="sorting1__options">
                <div class="dropdown js-dropdown"><a class="dropdown__head js-dropdown-head" href="#">
                        <div class="dropdown__text">Sort by:</div>
                        <div class="dropdown__category">Default</div>
                    </a>
                    <div class="dropdown__body js-dropdown-body">
                        <label class="checkbox checkbox_sm checkbox_green">
                            <input class="checkbox__input" type="checkbox" />
                            <span class="checkbox__in"><span class="checkbox__tick"></span><span
                                    class="checkbox__text">Project
                                    Name</span></span></label><label class="checkbox checkbox_sm checkbox_green"><input
                                class="checkbox__input" type="checkbox" checked="checked" /><span class="checkbox__in"><span
                                    class="checkbox__tick"></span><span class="checkbox__text">Newest
                                    Project</span></span></label><label class="checkbox checkbox_sm checkbox_green"><input
                                class="checkbox__input" type="checkbox" checked="checked" /><span class="checkbox__in"><span
                                    class="checkbox__tick"></span><span class="checkbox__text">Due
                                    Date</span></span></label><label class="checkbox checkbox_sm checkbox_green"><input
                                class="checkbox__input" type="checkbox" /><span class="checkbox__in"><span
                                    class="checkbox__tick"></span><span class="checkbox__text">Project
                                    Type</span></span></label>
                    </div>
                </div>
                <a class="sorting1__filters" href="#">
                    <svg class="icon icon-filters">
                        <use xlink:href="<?php echo e(asset('theme/img/sprite.svg#icon-filters')); ?>"></use>
                    </svg>
                </a>
                <a href="<?php echo e($url . '/create'); ?>" class="sorting1__btn btn rounded-pill text-white"
                    style="background-color:#ff5926 "><svg class="icon icon-plus">
                        <use xlink:href="<?php echo e(asset('theme/img/sprite.svg#icon-plus')); ?>"></use>
                    </svg>
                    <span class="btn__text">New User</span>
                </a>
            </div>
        </div>
    </div>
    <div class="products">
        <div class="products__container">
            <div class="products__body">
                <div class="products__head">
                    <div class="products__search"><button class="products__open"><svg class="icon icon-search">
                                <use xlink:href="img/sprite.svg#icon-search"></use>
                            </svg></button><input class="products__input" type="text" placeholder="Search…"></div><select
                        class="products__select">
                        <option>Action</option>
                        <option>Action</option>
                        <option>Action</option>
                    </select>
                </div>
                <div class="products__table">
                    <div class="products__row products__row_head">
                        <div class="products__cell"><label class="checkbox checkbox_green checkbox_big"><input
                                    class="checkbox__input" type="checkbox"><span class="checkbox__in"><span
                                        class="checkbox__tick"></span></span></label></div>
                        <div class="products__cell">#Id</div>
                        <div class="products__cell">First Name</div>
                        <div class="products__cell">Last Name</div>
                        <div class="products__cell">Email</div>
                        <div class="products__cell"></div>
                        <div class="products__cell">Action</div>
                    </div>
                    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="products__row">
                            <div class="products__cell"><label class="checkbox checkbox_green checkbox_big"><input
                                        class="checkbox__input" type="checkbox"><span class="checkbox__in"><span
                                            class="checkbox__tick"></span></span></label></div>
                            <div class="products__cell">
                                    <div class="products__title"><?php echo e($item->id); ?></div>
                            </div>
                            <div class="products__cell"><?php echo e($item->first_name); ?></div>
                            <div class="products__cell"><span
                                    class="products__note">id</span><span><?php echo e($item->last_name); ?></span></div>
                            <div class="products__cell"><span
                                    class="products__note">stock</span><span><?php echo e($item->email); ?></span></div>
                                     <div class="products__cell"><span
                                    class="products__note">stock</span><span></span></div>
                            <div class="products__cell">
                                <a href='<?php echo e($url . '/' . $item->id . '/edit'); ?>' class='toggle' data-target='editClass'><em
                                        class='icon ni ni-edit'></em><span>Edit</span></a>
                                <a href='javascript:'   onclick='deleteRecordAjax("<?php echo e($url."/".$item->id); ?>")' class='toggle' data-target='editClass'><em
                                        class='icon ni ni-edit'></em><span>Delete</span></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asadmirza/Documents/laravel/yuvi/resources/views/admin/user/index.blade.php ENDPATH**/ ?>