<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>YuVie-Business: Sign In</title>
    <?php echo $__env->make('admin.layout.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="out">
        <div class="login">
            <div class="login__container">
                <div class="login__wrap">
                    <div class="login__head">
                        <a class="login__logo" href="#">
                            <img class="login__pic w-50" src="<?php echo e(asset('theme/img/logo.png')); ?>" alt="">
                        </a>
                    </div>
                    <form class="login__form" action="<?php echo e(url('admin/login')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="login__body">
                            <div class="login__title login__title_sm">Login to your acount</div>
                            <div class="login__field field">
                                <small class="login__link"><?php echo e($errors->first('email')); ?></small>
                                <small class="login__link"><?php echo e($errors->first('password')); ?></small>
                            </div>
                            <div class="login__field field">
                                <div class="field__wrap">
                                    <input class="field__input" required type="email" name="email"
                                        placeholder="Your email">
                                </div>
                            </div>
                            <div class="login__field field">
                                <div class="field__wrap">
                                    <input class="field__input" required type="password" name="password"
                                        placeholder="Your password">
                                </div>
                            </div>
                            <button class="login__btn btn  rounded-pill text-white " style="background-color:#ff5926 " type="submit">Login</button>
                            <div class="login__or">or</div>
                            <div class="login__btns">
                                <button class="login__btn btn btn btn_border-gray" type="button">
                                    <img class="btn__pic" src="<?php echo e(asset('theme/img/google.svg')); ?>" alt=""
                                        width="16">
                                    <span class="btn__text">Continue with Google</span>
                                </button>
                                <button class="login__btn btn btn btn_border-gray" type="button">
                                    <img class="btn__pic" src="<?php echo e(asset('theme/img/facebook.svg')); ?>" alt=""
                                        width="16">
                                    <span class="btn__text">Continue with Facebook</span>
                                </button>
                            </div>
                            <ul class="login__links">
                                <li><a class="login__link" href="#">Can’t login?</a></li>
                                <li><a class="login__link" href="<?php echo e(url('register')); ?>">Sign up for new user?</a></li>
                            </ul>
                        </div>
                    </form>
                    <div class="login__bottom">
                        <ul class="login__links">
                            <li><a class="login__link" href="#">Privacy policy</a></li>
                            <li><a class="login__link" href="#">Terms of use</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <?php echo $__env->make('admin.layout.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /Users/asadmirza/Documents/laravel/yuvi/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>