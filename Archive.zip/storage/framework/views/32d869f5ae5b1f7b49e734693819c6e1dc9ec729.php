<script src="<?php echo e(asset('theme/js/app.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/common.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/charts.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('theme/js/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/my-custom.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH /Users/asadmirza/Documents/laravel/yuvi/resources/views/admin/layout/partials/script.blade.php ENDPATH**/ ?>