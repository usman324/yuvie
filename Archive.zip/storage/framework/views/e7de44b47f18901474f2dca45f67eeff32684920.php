<div class="header7 js-header7">
    <button class="header7__burger js-header7-burger">
        <svg class="icon icon-burger">
            <use xlink:href="<?php echo e(asset('theme/img/sprite.svg#icon-burger')); ?>"></use>
        </svg>
    </button>
    <a class="header7__logo" href="#">
        
        <img class="header7__pic header7__pic_black w-25" src="<?php echo e(asset('theme/img/logo.png')); ?>" alt="" />
        
    </a>
    <div class="header7__search"><button class="header7__open"><svg class="icon icon-search">
                <use xlink:href="<?php echo e(asset('theme/img/sprite.svg#icon-search')); ?>"></use>
            </svg>
        </button>
        <input class="header7__input" type="text" placeholder="Search…" />
    </div>
    <div class="header7__control">
        

        <button type="button"
            onclick="event.preventDefault();
            document.getElementById('logout-form').submit();"
            class="header7__notifications">
            <svg class="icon icon-bell">
                <use xlink:href="<?php echo e(asset('theme/img/sprite.svg#icon-logout')); ?>"></use>
            </svg>
        </button>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
        <a class="header7__user" href="#">
            <div class="ava">
                <img class="ava__pic" src="<?php echo e(asset('theme/img/ava-9.png')); ?>" alt="" />
            </div>
            <div class="header7__box">
                <div class="header7__man"><?php echo e(auth()->user()->first_name); ?></div>
                <div class="header7__post"><?php echo e(auth()->user()->last_name . '' . auth()->user()->first_name); ?></div>
            </div>
        </a>
    </div>
    <div class="header7__bg js-header7-bg"></div>
</div>
<?php /**PATH /Users/asadmirza/Documents/laravel/yuvi/resources/views/admin/layout/header.blade.php ENDPATH**/ ?>