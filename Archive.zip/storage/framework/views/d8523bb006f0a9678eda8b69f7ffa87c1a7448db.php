<?php $__env->startSection('style'); ?>
<title><?php echo e('YuVie-Business:'. $title); ?></title>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="sorting1">
        <div class="sorting1__row">
            <h1 class="sorting1__title title">User Create</h1>
        </div>
    </div>
    <div class="products">
        <div class="products__container">
            <div class="products__body">
                <form class="login__form" id="add-user">
                    <div class="login__body">
                        <div class="login__title login__title_sm ">User Detail</div>
                        <hr>
                        <div class="row login__field field">
                            <div class="col-6">
                                <div class="login__field field">
                                    <div class="field__wrap">
                                        <input class="field__input" required type="text" name="first_name"
                                            placeholder="First Name">
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="login__field field">
                                    <div class="field__wrap">
                                        <input class="field__input" required type="text" name="last_name"
                                            placeholder="Last Name">
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="login__field field">
                            <div class="field__wrap">
                                <input class="field__input" required type="email" name="email" placeholder="Your email">
                            </div>
                        </div>
                        <div class="row login__field field">

                            <div class="col-6">
                                <div class="login__field field">
                                    <div class="field__wrap">
                                        <input class="field__input" required type="password" name="password"
                                            placeholder="Your password">
                                    </div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="login__field field">
                                    <div class="field__wrap">
                                        <input class="field__input" required type="password" name="password_confirmation"
                                            placeholder="Confirm Password">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="login__field field">
                            <button type="button"
                                onclick="addFormData(event,'post','<?php echo e(url('admin/users')); ?>','<?php echo e(url('admin/users')); ?>','add-user')"
                                class="btn btn-sm rounded-pill text-white" style="background-color:#ff5926 "
                               >Add
                            </button>
                            <a href="<?php echo e($url); ?>" class="btn btn-sm  rounded-pill border-info" style=""
                                type="submit">Cancel
                            </a>
                        </div>
                    </div>
                </form>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asadmirza/Documents/laravel/yuvi/resources/views/admin/user/create.blade.php ENDPATH**/ ?>